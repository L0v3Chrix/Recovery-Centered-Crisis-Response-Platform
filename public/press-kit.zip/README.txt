# HelpNow ATX Partner Kit

Thank you for partnering with HelpNow ATX to help connect Central Texas residents with verified help resources.

## Badge Files

This kit includes three badge designs:
- **badge-pill**: Gradient pill design (recommended)
- **badge-dark**: Dark background variant
- **badge-outline**: Outline design for light backgrounds

Each badge is provided in both SVG (scalable) and PNG formats.

## How to Use

1. Choose your preferred badge design
2. Copy the code from embed.html
3. Paste it into your website's HTML

## Link Back

All badges should link to: https://helpnowatx.org/

The embed code includes UTM tracking parameters to help us understand which partners are driving the most awareness.

## Questions?

Contact us through the website at helpnowatx.org/partners

---

© HelpNow ATX - Real help, verified daily